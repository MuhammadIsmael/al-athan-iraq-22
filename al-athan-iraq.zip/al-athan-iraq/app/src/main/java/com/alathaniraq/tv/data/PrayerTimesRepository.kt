package com.alathaniraq.tv.data

class PrayerTimesRepository(private val api: AladhanApi = AladhanApi.create()) {

    suspend fun fetchToday(latitude: Double, longitude: Double): Result<AladhanData> {
        return fetchForTimestamp(latitude, longitude, System.currentTimeMillis() / 1000)
    }

    /** [timestampSeconds] selects which day's timings come back — e.g. tomorrow's, to
     *  find Fajr once today's prayers have all passed. */
    suspend fun fetchForTimestamp(latitude: Double, longitude: Double, timestampSeconds: Long): Result<AladhanData> {
        return try {
            val response = api.getTimings(
                latitude = latitude,
                longitude = longitude,
                timestamp = timestampSeconds
            )
            val data = response.data
            if (data != null) Result.success(data) else Result.failure(IllegalStateException("Empty response"))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
