package com.alathaniraq.tv.ui

import android.os.Bundle
import com.alathaniraq.tv.BuildConfig
import com.alathaniraq.tv.R
import com.alathaniraq.tv.databinding.ActivityAboutBinding
import com.alathaniraq.tv.util.DateFormatting

class AboutActivity : BaseActivity() {

    private lateinit var binding: ActivityAboutBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAboutBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // getString(R.string.version_format, ...) would format the version number
        // using the app's active locale, which can substitute Eastern Arabic/Kurdish
        // digits — build it manually with a forced Western-digit locale instead.
        val versionLabel = String.format(
            DateFormatting.WESTERN_DIGITS,
            getString(R.string.version_format),
            BuildConfig.VERSION_NAME
        )
        binding.versionText.text = versionLabel
        binding.closeButton.setOnClickListener { finish() }
        binding.closeButton.requestFocus()
    }
}
