package com.alathaniraq.tv.ui

import android.content.Context
import androidx.core.content.ContextCompat
import com.alathaniraq.tv.R
import com.alathaniraq.tv.util.Prefs

/**
 * A color scheme covers exactly the elements the person asked to be able to re-color:
 * prayer card text, "Next prayer in" + the countdown, the clock/date text, and the
 * home screen background. Everything else (borders, card fill colors, icons) stays as
 * designed — this is a text/background palette, not a full re-skin.
 */
data class ColorScheme(
    val id: String,
    val labelRes: Int,
    val background: Int,
    val primaryText: Int,
    val accentText: Int
)

object ColorSchemes {

    fun all(context: Context): List<ColorScheme> = listOf(
        ColorScheme(
            "teal_gold", R.string.scheme_teal_gold,
            ContextCompat.getColor(context, R.color.mosque_green_dark),
            ContextCompat.getColor(context, R.color.text_primary),
            ContextCompat.getColor(context, R.color.gold_accent)
        ),
        ColorScheme(
            "midnight_silver", R.string.scheme_midnight_silver,
            0xFF0D1B2A.toInt(),
            0xFFF0F4F8.toInt(),
            0xFFB8C4CE.toInt()
        ),
        ColorScheme(
            "emerald_gold", R.string.scheme_emerald_gold,
            0xFF0B3D2E.toInt(),
            0xFFF7F3E9.toInt(),
            0xFFD4AF37.toInt()
        ),
        ColorScheme(
            "royal_purple", R.string.scheme_royal_purple,
            0xFF2A1A3E.toInt(),
            0xFFF3EEFA.toInt(),
            0xFFE0B84A.toInt()
        ),
        ColorScheme(
            "slate_blue", R.string.scheme_slate_blue,
            0xFF15263B.toInt(),
            0xFFEAF1F8.toInt(),
            0xFF4FC3D9.toInt()
        )
    )

    fun current(context: Context): ColorScheme {
        val id = Prefs.getColorSchemeId(context)
        return all(context).firstOrNull { it.id == id } ?: all(context).first()
    }
}
