package com.alathaniraq.tv.ui

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import com.alathaniraq.tv.BuildConfig
import com.alathaniraq.tv.R
import com.alathaniraq.tv.databinding.ActivityHubMenuBinding
import com.alathaniraq.tv.util.DateFormatting

/**
 * The screen the hamburger button actually opens now. "Home" returns to whichever
 * home screen is showing; "Settings" opens the existing MenuActivity (Change
 * Location, Iqama, Color Scheme, etc.); "About", "Share", and "Rate Us" are new here.
 * About was removed from MenuActivity since it lives here now instead — see that
 * class's doc comment.
 *
 * Propagates RESULT_OK to the home screen exactly like MenuActivity always has, so a
 * settings change made two levels deep (Home screen -> this hub -> Settings -> e.g.
 * District picker) still triggers the right refresh/recreate back at the home screen.
 */
class HubMenuActivity : BaseActivity() {

    private lateinit var binding: ActivityHubMenuBinding
    private var didChange = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHubMenuBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.hubVersion.text = String.format(
            DateFormatting.WESTERN_DIGITS,
            getString(R.string.version_format),
            BuildConfig.VERSION_NAME
        )

        binding.hubHome.isActivated = true

        binding.hubHome.setOnClickListener { finish() }

        binding.hubSettings.setOnClickListener {
            startActivityForResult(Intent(this, MenuActivity::class.java), REQUEST_SETTINGS)
        }

        binding.hubAbout.setOnClickListener {
            startActivity(Intent(this, AboutActivity::class.java))
        }

        binding.hubShare.setOnClickListener { shareApp() }

        binding.hubRateUs.setOnClickListener { openStoreListing() }

        binding.hubQuit.setOnClickListener { finishAffinity() }

        binding.hubHome.requestFocus()
    }

    private fun shareApp() {
        val shareText = getString(R.string.share_text, storeUrl())
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, shareText)
        }
        startActivity(Intent.createChooser(intent, getString(R.string.share)))
    }

    private fun openStoreListing() {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=${BuildConfig.APPLICATION_ID}")))
        } catch (e: ActivityNotFoundException) {
            // No Play Store app installed (common on some TV boxes) — fall back to the browser.
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(storeUrl())))
        }
    }

    private fun storeUrl() = "https://play.google.com/store/apps/details?id=${BuildConfig.APPLICATION_ID}"

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_SETTINGS && resultCode == Activity.RESULT_OK) {
            didChange = true
        }
    }

    private fun finishWithResult() {
        setResult(if (didChange) Activity.RESULT_OK else Activity.RESULT_CANCELED)
    }

    override fun finish() {
        finishWithResult()
        super.finish()
    }

    companion object {
        private const val REQUEST_SETTINGS = 100
    }
}
