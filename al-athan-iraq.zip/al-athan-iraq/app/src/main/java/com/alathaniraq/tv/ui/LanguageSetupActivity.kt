package com.alathaniraq.tv.ui

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import com.alathaniraq.tv.BuildConfig
import com.alathaniraq.tv.R
import com.alathaniraq.tv.databinding.ActivityLanguageSetupBinding
import com.alathaniraq.tv.util.DateFormatting
import com.alathaniraq.tv.util.Prefs

/**
 * Doubles as both the first screen of first-launch setup AND the "Change Language"
 * screen reachable from Settings later (see MenuActivity). Which mode it's in is
 * decided by EXTRA_FROM_SETTINGS:
 * - First-launch (extra absent/false): "Next" saves the language and continues to
 *   OrientationSetupActivity, same as before.
 * - From Settings (extra true): the button reads "Done", saves the language, and
 *   returns RESULT_OK to the caller (which should recreate() to reload strings)
 *   instead of continuing the onboarding chain.
 *
 * Selection highlight is a fixed green (onboarding_row_bg.xml's state_activated),
 * matching the reference design exactly — onboarding is a dedicated brand moment
 * shown before any theme choice, so it deliberately does NOT follow Settings > Color
 * Scheme the way the rest of the app does.
 */
class LanguageSetupActivity : BaseActivity() {

    private lateinit var binding: ActivityLanguageSetupBinding
    private var selected: String = Prefs.LANGUAGE_ENGLISH
    private var fromSettings: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLanguageSetupBinding.inflate(layoutInflater)
        setContentView(binding.root)

        fromSettings = intent.getBooleanExtra(EXTRA_FROM_SETTINGS, false)
        if (fromSettings) {
            binding.nextButton.setText(com.alathaniraq.tv.R.string.done)
        }

        binding.versionText.text = String.format(
            DateFormatting.WESTERN_DIGITS,
            getString(R.string.version_format),
            BuildConfig.VERSION_NAME
        )

        selected = Prefs.getAppLanguage(this)

        binding.optionEnglish.setOnClickListener { select(Prefs.LANGUAGE_ENGLISH) }
        binding.optionArabic.setOnClickListener { select(Prefs.LANGUAGE_ARABIC) }
        binding.optionKurdish.setOnClickListener { select(Prefs.LANGUAGE_KURDISH_SORANI) }
        // Explicit initial D-pad focus for TV/TV-box remotes — matters especially here
        // since this can be the very first screen a person sees on first launch.
        binding.optionEnglish.requestFocus()

        binding.nextButton.setOnClickListener {
            Prefs.setAppLanguage(this, selected)
            if (fromSettings) {
                setResult(Activity.RESULT_OK)
                finish()
            } else {
                startActivity(Intent(this, OrientationSetupActivity::class.java))
                // Recreate isn't needed here — OrientationSetupActivity's attachBaseContext
                // picks up the just-saved language fresh when it's created.
                finish()
            }
        }

        refreshSelection()
    }

    private fun select(language: String) {
        selected = language
        refreshSelection()
    }

    private fun refreshSelection() {
        binding.optionEnglish.isActivated = selected == Prefs.LANGUAGE_ENGLISH
        binding.optionArabic.isActivated = selected == Prefs.LANGUAGE_ARABIC
        binding.optionKurdish.isActivated = selected == Prefs.LANGUAGE_KURDISH_SORANI
    }

    companion object {
        const val EXTRA_FROM_SETTINGS = "from_settings"
    }
}
