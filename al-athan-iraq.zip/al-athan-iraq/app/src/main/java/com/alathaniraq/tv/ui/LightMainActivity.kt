package com.alathaniraq.tv.ui

import android.app.Activity
import android.content.Intent
import android.net.ConnectivityManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.lifecycle.lifecycleScope
import com.alathaniraq.tv.R
import com.alathaniraq.tv.data.IraqRegions
import com.alathaniraq.tv.data.PrayerTimesRepository
import com.alathaniraq.tv.data.Timings
import com.alathaniraq.tv.databinding.ActivityMainLightBinding
import com.alathaniraq.tv.databinding.ItemPrayerCardLightBinding
import com.alathaniraq.tv.util.AthanScheduler
import com.alathaniraq.tv.util.DateFormatting
import com.alathaniraq.tv.util.NetworkStatus
import com.alathaniraq.tv.util.Prefs
import kotlinx.coroutines.launch
import java.util.Calendar

/**
 * The "Light" home screen design: a light/cream backdrop, two side-by-side info cards
 * (clock+date+location, and next-prayer countdown), six mosque-arch-shaped prayer
 * cards each showing its Iqama time (the one home screen design that does — everywhere
 * else Iqama is settings-only, but this design's reference explicitly includes it per
 * card), and a scrolling verse ticker along the bottom.
 *
 * On Fridays, the Dhuhr slot becomes Jumua throughout (countdown, label, and the
 * Dhuhr-position card), matching the reference design exactly.
 */
class LightMainActivity : BaseActivity() {

    private lateinit var binding: ActivityMainLightBinding
    private val repository = PrayerTimesRepository()
    private val handler = Handler(Looper.getMainLooper())
    private var currentTimings: Timings? = null
    private var currentLocation: IraqRegions.ResolvedLocation =
        IraqRegions.resolveLocation(IraqRegions.defaultDistrict().id, null)
    private var timingsDayOfYear: Int = -1
    private var tomorrowFajr: String? = null
    private var tomorrowFajrRequestInFlight = false
    private var networkCallback: ConnectivityManager.NetworkCallback? = null

    private val tickRunnable = object : Runnable {
        override fun run() {
            binding.currentTime.text = DateFormatting.currentClockTime()
            updateCountdown()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainLightBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.menuButton.setOnClickListener {
            startActivityForResult(Intent(this, HubMenuActivity::class.java), REQUEST_MENU)
        }
        binding.menuButton.requestFocus()

        binding.nextPrayerLabel.text = getString(R.string.time_remaining_prefix)
        binding.tickerText.text = getString(R.string.ticker_verse)
        binding.tickerText.isSelected = true // required to actually start the marquee scroll

        binding.currentTime.text = DateFormatting.currentClockTime()
        refresh()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_MENU && resultCode == Activity.RESULT_OK) {
            val target = HomeScreenRouter.launcherActivityClass(this)
            if (target != LightMainActivity::class.java) {
                startActivity(Intent(this, target))
                finish()
            } else {
                refresh()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        handler.post(tickRunnable)
        setOnlineStatus(NetworkStatus.isOnline(this))
        networkCallback = NetworkStatus.registerCallback(this) { online ->
            runOnUiThread { setOnlineStatus(online) }
        }
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(tickRunnable)
        NetworkStatus.unregister(this, networkCallback)
        networkCallback = null
    }

    private fun setOnlineStatus(online: Boolean) {
        binding.onlineStatusText.text = getString(if (online) R.string.online else R.string.offline)
    }

    private fun refresh() {
        currentLocation = IraqRegions.resolveLocation(Prefs.getDistrictId(this), Prefs.getSubDistrictId(this))
        binding.locationPill.text = currentLocation.displayName

        lifecycleScope.launch {
            val result = repository.fetchToday(currentLocation.latitude, currentLocation.longitude)
            result.onSuccess { data ->
                currentTimings = data.timings
                timingsDayOfYear = Calendar.getInstance().get(Calendar.DAY_OF_YEAR)
                tomorrowFajr = null
                tomorrowFajrRequestInFlight = false

                val (hijriLine, gregorianLine) = DateFormatting.lightHeaderDates(this@LightMainActivity, data.date.hijri)
                binding.dateHijri.text = hijriLine
                binding.dateGregorian.text = gregorianLine

                val isFriday = Calendar.getInstance().get(Calendar.DAY_OF_WEEK) == Calendar.FRIDAY
                val dhuhrLabel = if (isFriday) getString(R.string.jumua) else getString(R.string.dhuhr)
                val dhuhrTime = if (isFriday) jumuaTime(data.timings.dhuhr) else data.timings.dhuhr

                bindCard(binding.cardFajr, getString(R.string.fajr), data.timings.fajr, "fajr", R.drawable.ic_moon)
                bindCard(binding.cardShuruk, getString(R.string.shuruk), data.timings.sunrise, null, R.drawable.ic_sun)
                bindCard(binding.cardDhuhr, dhuhrLabel, dhuhrTime, if (isFriday) null else "dhuhr", R.drawable.ic_sun)
                bindCard(binding.cardAsr, getString(R.string.asr), data.timings.asr, "asr", R.drawable.ic_cloud_sun)
                bindCard(binding.cardMaghrib, getString(R.string.maghrib), data.timings.maghrib, "maghrib", R.drawable.ic_sunset)
                bindCard(binding.cardIsha, getString(R.string.isha), data.timings.isha, "isha", R.drawable.ic_moon_star)

                updateCountdown()
                AthanScheduler.scheduleToday(this@LightMainActivity, data.timings)
            }.onFailure {
                binding.countdown.text = getString(R.string.error_loading)
            }
        }
    }

    /** Shuruk has no Iqama (it isn't a prayer); the Friday Jumua slot also hides the
     *  usual daily-Iqama figure since Jumua's own adjustable time already serves that
     *  role — passing null for [iqamaKey] hides the Iqama row entirely. */
    private fun bindCard(
        cardBinding: ItemPrayerCardLightBinding,
        name: String,
        time: String,
        iqamaKey: String?,
        iconRes: Int
    ) {
        cardBinding.prayerIcon.setImageResource(iconRes)
        cardBinding.prayerIcon.setColorFilter(getColor(R.color.light_text_dark))
        cardBinding.prayerName.text = name
        // Cards are compact — drop the AM/PM suffix rather than shrink it further.
        cardBinding.prayerTime.text = DateFormatting.to12Hour(time).substringBeforeLast(" ")
        if (iqamaKey != null) {
            cardBinding.prayerIqamaLabel.visibility = android.view.View.VISIBLE
            cardBinding.prayerIqamaTime.visibility = android.view.View.VISIBLE
            val iqama = DateFormatting.addMinutes(time, Prefs.getIqamaOffset(this, iqamaKey))
            cardBinding.prayerIqamaTime.text = DateFormatting.to12Hour(iqama).substringBeforeLast(" ")
        } else {
            cardBinding.prayerIqamaLabel.visibility = android.view.View.INVISIBLE
            cardBinding.prayerIqamaTime.visibility = android.view.View.INVISIBLE
        }
    }

    private fun jumuaTime(dhuhr: String): String {
        return if (Prefs.getJumuaMatchDhuhr(this)) {
            dhuhr
        } else {
            DateFormatting.addMinutes(dhuhr, Prefs.getJumuaOffset(this))
        }
    }

    private fun updateCountdown() {
        val timings = currentTimings ?: return
        val now = Calendar.getInstance()

        if (timingsDayOfYear != -1 && now.get(Calendar.DAY_OF_YEAR) != timingsDayOfYear) {
            refresh()
            return
        }

        val isFriday = now.get(Calendar.DAY_OF_WEEK) == Calendar.FRIDAY
        val dhuhrLabel = if (isFriday) getString(R.string.jumua) else getString(R.string.dhuhr)
        val dhuhrTime = if (isFriday) jumuaTime(timings.dhuhr) else timings.dhuhr

        val order = listOf(
            getString(R.string.fajr) to timings.fajr,
            dhuhrLabel to dhuhrTime,
            getString(R.string.asr) to timings.asr,
            getString(R.string.maghrib) to timings.maghrib,
            getString(R.string.isha) to timings.isha
        )

        var nextIndex = -1
        var nextMillis = Long.MAX_VALUE
        var nextName = ""

        order.forEachIndexed { index, (name, time) ->
            val parts = time.take(5).split(":")
            if (parts.size != 2) return@forEachIndexed
            val hour = parts[0].toIntOrNull() ?: return@forEachIndexed
            val minute = parts[1].toIntOrNull() ?: return@forEachIndexed
            val target = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, hour)
                set(Calendar.MINUTE, minute)
                set(Calendar.SECOND, 0)
            }
            if (target.after(now) && target.timeInMillis < nextMillis) {
                nextMillis = target.timeInMillis
                nextIndex = index
                nextName = name
            }
        }

        val cards = listOf(binding.cardFajr, binding.cardShuruk, binding.cardDhuhr, binding.cardAsr, binding.cardMaghrib, binding.cardIsha)
        // Card row order is Fajr, Shuruk, Dhuhr/Jumua, Asr, Maghrib, Isha — Shuruk (index
        // 1) never highlights as "next" since it isn't a prayer; the countdown's own
        // `order` list has no Shuruk entry, so its indices need remapping onto the cards.
        val highlightCardIndex = when (nextIndex) {
            0 -> 0 // Fajr
            1 -> 2 // Dhuhr/Jumua
            2 -> 3 // Asr
            3 -> 4 // Maghrib
            4 -> 5 // Isha
            else -> -1
        }
        cards.forEachIndexed { index, card ->
            card.cardBackground.setImageResource(
                if (index == highlightCardIndex) R.drawable.arch_card_light_selected else R.drawable.arch_card_light
            )
        }

        if (nextIndex == -1) {
            val fajrTomorrow = tomorrowFajr
            if (fajrTomorrow == null) {
                ensureTomorrowFajrLoaded()
                binding.nextPrayerName.text = getString(R.string.fajr)
                binding.countdown.text = "--:--:--"
                return
            }
            val parts = fajrTomorrow.take(5).split(":")
            val hour = parts.getOrNull(0)?.toIntOrNull()
            val minute = parts.getOrNull(1)?.toIntOrNull()
            if (hour != null && minute != null) {
                val target = Calendar.getInstance().apply {
                    add(Calendar.DAY_OF_YEAR, 1)
                    set(Calendar.HOUR_OF_DAY, hour)
                    set(Calendar.MINUTE, minute)
                    set(Calendar.SECOND, 0)
                }
                binding.cardFajr.cardBackground.setImageResource(R.drawable.arch_card_light_selected)
                binding.nextPrayerName.text = getString(R.string.fajr)
                binding.countdown.text = formatCountdown(target.timeInMillis - now.timeInMillis)
            }
            return
        }

        binding.nextPrayerName.text = nextName
        binding.countdown.text = formatCountdown(nextMillis - now.timeInMillis)
    }

    private fun formatCountdown(diffMs: Long): String {
        val diff = diffMs / 1000
        val h = diff / 3600
        val m = (diff % 3600) / 60
        val s = diff % 60
        return String.format(DateFormatting.WESTERN_DIGITS, "%02d:%02d:%02d", h, m, s)
    }

    private fun ensureTomorrowFajrLoaded() {
        if (tomorrowFajrRequestInFlight) return
        tomorrowFajrRequestInFlight = true
        val tomorrowTimestamp = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, 1) }.timeInMillis / 1000
        lifecycleScope.launch {
            val result = repository.fetchForTimestamp(currentLocation.latitude, currentLocation.longitude, tomorrowTimestamp)
            result.onSuccess { data -> tomorrowFajr = data.timings.fajr }
            tomorrowFajrRequestInFlight = false
        }
    }

    companion object {
        private const val REQUEST_MENU = 200
    }
}
