package com.alathaniraq.tv.ui

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import com.alathaniraq.tv.databinding.ActivityMenuBinding

/**
 * The hamburger-button menu, matching the reference design's order:
 * 1. Change Location
 * 2. Iqama
 * 3. Change Home Screen
 * 4. Color Scheme
 * 5. Jumua (Friday Prayer) Times Adjustment
 * 6. Change Language
 *
 * (About now lives one level up, on the Hub screen that opens this menu — see
 * HubMenuActivity — so it isn't duplicated here.)
 *
 * Returns RESULT_OK to the home screen if anything changed that requires a refresh
 * (location, iqama offsets, home screen design, color scheme, Jumua settings, or
 * language).
 */
class MenuActivity : BaseActivity() {

    private lateinit var binding: ActivityMenuBinding
    private var didChange = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMenuBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.menuChangeCity.setOnClickListener {
            startActivityForResult(Intent(this, DistrictPickerActivity::class.java), REQUEST_CITY)
        }
        binding.menuIqama.setOnClickListener {
            startActivityForResult(Intent(this, IqamaSettingsActivity::class.java), REQUEST_IQAMA)
        }
        binding.menuHomeScreen.setOnClickListener {
            startActivityForResult(Intent(this, HomeScreenPickerActivity::class.java), REQUEST_HOME_SCREEN)
        }
        binding.menuColorScheme.setOnClickListener {
            startActivityForResult(Intent(this, ColorSchemePickerActivity::class.java), REQUEST_COLOR_SCHEME)
        }
        binding.menuJumua.setOnClickListener {
            startActivityForResult(Intent(this, JumuaSettingsActivity::class.java), REQUEST_JUMUA)
        }
        binding.menuLanguage.setOnClickListener {
            val intent = Intent(this, LanguageSetupActivity::class.java)
            intent.putExtra(LanguageSetupActivity.EXTRA_FROM_SETTINGS, true)
            startActivityForResult(intent, REQUEST_LANGUAGE)
        }

        binding.menuChangeCity.requestFocus()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK &&
            (requestCode == REQUEST_CITY || requestCode == REQUEST_IQAMA ||
                requestCode == REQUEST_HOME_SCREEN || requestCode == REQUEST_COLOR_SCHEME ||
                requestCode == REQUEST_JUMUA || requestCode == REQUEST_LANGUAGE)
        ) {
            didChange = true
        }
    }

    private fun finishWithResult() {
        setResult(if (didChange) Activity.RESULT_OK else Activity.RESULT_CANCELED)
    }

    override fun finish() {
        finishWithResult()
        super.finish()
    }

    companion object {
        private const val REQUEST_CITY = 100
        private const val REQUEST_IQAMA = 101
        private const val REQUEST_HOME_SCREEN = 102
        private const val REQUEST_COLOR_SCHEME = 103
        private const val REQUEST_JUMUA = 104
        private const val REQUEST_LANGUAGE = 105
    }
}
