package com.alathaniraq.tv.ui

import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.widget.Button
import com.alathaniraq.tv.R

object OnboardingUi {

    /**
     * Highlights [button] with the app's current color-scheme accent when selected,
     * or the standard outlined look otherwise. A GradientDrawable is built at runtime
     * (rather than a plain background color) so the rounded corners are preserved.
     */
    fun highlight(context: Context, button: Button, isSelected: Boolean, accentColor: Int) {
        if (isSelected) {
            val shape = GradientDrawable()
            shape.shape = GradientDrawable.RECTANGLE
            shape.cornerRadius = 8f * context.resources.displayMetrics.density
            shape.setColor(accentColor)
            button.background = shape
        } else {
            button.setBackgroundResource(R.drawable.button_outline)
        }
    }
}
