package com.alathaniraq.tv.util

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import com.alathaniraq.tv.R
import com.alathaniraq.tv.ui.AthanDisplayActivity

class AthanAlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val prayerKey = intent.getStringExtra(EXTRA_PRAYER_NAME)

        // NOTE: res/raw/athan.mp3 is not bundled in this source tree — add your own
        // licensed athan audio file there before building. See README.
        try {
            val player = MediaPlayer()
            val afd = context.resources.openRawResourceFd(R.raw.athan)
            player.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
            afd.close()
            player.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            player.setOnCompletionListener { it.release() }
            player.prepare()
            player.start()
        } catch (e: Exception) {
            // No athan.mp3 present, or playback failed — fail silently rather than crash.
        }

        // Show the full-screen "{Prayer} Al-Athan" takeover on top of whatever's running.
        // FLAG_ACTIVITY_NEW_TASK is required since this starts from a BroadcastReceiver,
        // not from within an existing Activity's task. On some Android versions/OEMs,
        // background-activity-launch restrictions can prevent this from actually
        // appearing if the app isn't already in the foreground and the device doesn't
        // grant an exemption for alarm-triggered launches — the athan sound above still
        // plays regardless, so that part of the experience isn't affected either way.
        try {
            val displayIntent = Intent(context, AthanDisplayActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                putExtra(EXTRA_PRAYER_NAME, prayerKey)
            }
            context.startActivity(displayIntent)
        } catch (e: Exception) {
            // Launch restricted or otherwise failed — don't crash the receiver over it.
        }
    }

    companion object {
        const val EXTRA_PRAYER_NAME = "extra_prayer_name"
    }
}
